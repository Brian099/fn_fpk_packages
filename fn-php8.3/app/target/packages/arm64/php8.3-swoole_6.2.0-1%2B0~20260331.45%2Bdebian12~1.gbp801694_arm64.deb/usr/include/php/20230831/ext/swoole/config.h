/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Whether to build swoole as dynamic module */
#define COMPILE_DL_SWOOLE 1

/* have accept4 */
#define HAVE_ACCEPT4 1

/* Whether you have AI_ALL */
#define HAVE_AI_ALL 1

/* Whether you have AI_IDN */
/* #undef HAVE_AI_IDN */

/* Whether you have AI_V4MAPPED */
#define HAVE_AI_V4MAPPED 1

/* have arc4random */
#define HAVE_ARC4RANDOM 1

/* have boost-stacktrace? */
/* #undef HAVE_BOOST_STACKTRACE */

/* have c-ares */
#define HAVE_CARES 1

/* have_ccrandomgeneratebytes */
/* #undef HAVE_CCRANDOMGENERATEBYTES */

/* Define to 1 if you have the <cli0cli.h> header file. */
/* #undef HAVE_CLI0CLI_H */

/* Define to 1 if you have the <cli0core.h> header file. */
/* #undef HAVE_CLI0CORE_H */

/* Define to 1 if you have the <cli0defs.h> header file. */
/* #undef HAVE_CLI0DEFS_H */

/* Define to 1 if you have the <cli0env.h> header file. */
/* #undef HAVE_CLI0ENV_H */

/* Define to 1 if you have the <cli0ext.h> header file. */
/* #undef HAVE_CLI0EXT_H */

/* cpu affinity? */
#define HAVE_CPU_AFFINITY 1

/* have daemon */
#define HAVE_DAEMON 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* have epoll */
#define HAVE_EPOLL 1

/* have eventfd */
#define HAVE_EVENTFD 1

/* have execinfo */
#define HAVE_EXECINFO 1

/* have FUTEX? */
#define HAVE_FUTEX 1

/* have gethostbyname2_r */
#define HAVE_GETHOSTBYNAME2_R 1

/* have getrandom */
#define HAVE_GETRANDOM 1

/* Define to 1 if you have the `hstrerror' function. */
#define HAVE_HSTRERROR 1

/* Define to 1 if you have the `if_indextoname' function. */
#define HAVE_IF_INDEXTONAME 1

/* Define to 1 if you have the `if_nametoindex' function. */
#define HAVE_IF_NAMETOINDEX 1

/* have inotify */
#define HAVE_INOTIFY 1

/* have inotify_init1 */
#define HAVE_INOTIFY_INIT1 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <iodbc.h> header file. */
/* #undef HAVE_IODBC_H */

/* have io_uring ftruncate? */
/* #undef HAVE_IOURING_FTRUNCATE */

/* have io_uring futex? */
/* #undef HAVE_IOURING_FUTEX */

/* have io_uring statx? */
/* #undef HAVE_IOURING_STATX */

/* Define to 1 if you have the <isqlext.h> header file. */
/* #undef HAVE_ISQLEXT_H */

/* Define to 1 if you have the <isql.h> header file. */
/* #undef HAVE_ISQL_H */

/* have kqueue */
/* #undef HAVE_KQUEUE */

/* Define to 1 if you have the <LibraryManager.h> header file. */
/* #undef HAVE_LIBRARYMANAGER_H */

/* Define to 1 if you have the `rt' library (-lrt). */
/* #undef HAVE_LIBRT */

/* have malloc_trim */
#define HAVE_MALLOC_TRIM 1

/* have mkostemp */
#define HAVE_MKOSTEMP 1

/* have sysv message queue? */
#define HAVE_MSGQUEUE 1

/* have pthread_mutex_timedlock */
#define HAVE_MUTEX_TIMEDLOCK 1

/* Define to 1 if you have the <netdb.h> header file. */
#define HAVE_NETDB_H 1

/* Define to 1 if you have the <netinet/tcp.h> header file. */
#define HAVE_NETINET_TCP_H 1

/* */
/* #undef HAVE_OCIENVCREATE */

/* */
/* #undef HAVE_OCIENVNLSCREATE */

/* */
/* #undef HAVE_OCILOBREAD2 */

/* */
/* #undef HAVE_OCISTMTFETCH2 */

/* Define to 1 if you have the <odbcsdk.h> header file. */
/* #undef HAVE_ODBCSDK_H */

/* Define to 1 if you have the <odbc.h> header file. */
/* #undef HAVE_ODBC_H */

/* have pthread_barrier_init */
#define HAVE_PTHREAD_BARRIER 1

/* have pthread_mutexattr_setpshared */
#define HAVE_PTHREAD_MUTEXATTR_SETPSHARED 1

/* have pthread_mutexattr_setrobust */
#define HAVE_PTHREAD_MUTEXATTR_SETROBUST 1

/* have pthread_mutex_consistent */
#define HAVE_PTHREAD_MUTEX_CONSISTENT 1

/* have ptrace */
#define HAVE_PTRACE 1

/* have SO_REUSEPORT? */
#define HAVE_REUSEPORT 1

/* have pthread_rwlock_init */
#define HAVE_RWLOCK 1

/* have pthread_rwlock_timedrdlock */
#define HAVE_RWLOCK_TIMEDRDLOCK 1

/* have pthread_rwlock_timedwrlock */
#define HAVE_RWLOCK_TIMEDWRLOCK 1

/* have sendfile */
#define HAVE_SENDFILE 1

/* have signalfd */
#define HAVE_SIGNALFD 1

/* Define to 1 if you have the `socketpair' function. */
#define HAVE_SOCKETPAIR 1

/* */
#define HAVE_SOCKETS 1

/* have pthread_spin_lock */
#define HAVE_SPINLOCK 1

/* Define to 1 if you have the <sqlcli1.h> header file. */
/* #undef HAVE_SQLCLI1_H */

/* Define to 1 if you have the <sqlext.h> header file. */
/* #undef HAVE_SQLEXT_H */

/* Define to 1 if you have the <sqltypes.h> header file. */
/* #undef HAVE_SQLTYPES_H */

/* Define to 1 if you have the <sqlucode.h> header file. */
/* #undef HAVE_SQLUCODE_H */

/* Define to 1 if you have the <sqlunix.h> header file. */
/* #undef HAVE_SQLUNIX_H */

/* Define to 1 if you have the <sql.h> header file. */
/* #undef HAVE_SQL_H */

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the pdo_sqlite extension enabled. */
#define HAVE_SW_PDO_SQLITELIB 1

/* have sqlite3_close_v2 */
#define HAVE_SW_SQLITE3_CLOSE_V2 1

/* have sqlite3_column_table_name */
#define HAVE_SW_SQLITE3_COLUMN_TABLE_NAME 1

/* Define to 1 if you have the <sys/sockio.h> header file. */
/* #undef HAVE_SYS_SOCKIO_H */

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <sys/un.h> header file. */
#define HAVE_SYS_UN_H 1

/* have ucontext? */
#define HAVE_UCONTEXT 1

/* Define to 1 if you have the <udbcext.h> header file. */
/* #undef HAVE_UDBCEXT_H */

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* have valgrind? */
/* #undef HAVE_VALGRIND */

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Define to the address where bug reports for this package should be sent. */
/* #undef PACKAGE_BUGREPORT */

/* Define to the full name of this package. */
/* #undef PACKAGE_NAME */

/* Define to the full name and version of this package. */
/* #undef PACKAGE_STRING */

/* Define to the one symbol short name of this package. */
/* #undef PACKAGE_TARNAME */

/* Define to the home page for this package. */
/* #undef PACKAGE_URL */

/* Define to the version of this package. */
/* #undef PACKAGE_VERSION */

/* Have libssh2 with ssh-agent support */
/* #undef PHP_SSH2_AGENT_AUTH */

/* Have libssh2 with session timeout support */
/* #undef PHP_SSH2_SESSION_TIMEOUT */

/* The size of `long', as computed by sizeof. */
/* #undef SIZEOF_LONG */

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* */
/* #undef SWOOLE_PDO_OCI_CLIENT_VERSION */

/* do we enable to calculate coroutine execution time */
/* #undef SW_CORO_TIME */

/* do we enable swoole debug */
/* #undef SW_DEBUG */

/* have brotli */
/* #undef SW_HAVE_BROTLI */

/* have swoole-ftp */
/* #undef SW_HAVE_FTP */

/* have swoole-ftp with SSL */
/* #undef SW_HAVE_FTP_SSL */

/* Have libssh2 */
/* #undef SW_HAVE_SSH2LIB */

/* have zlib */
#define SW_HAVE_ZLIB 1

/* have zstd */
#define SW_HAVE_ZSTD 1

/* enable trace log */
/* #undef SW_LOG_TRACE_OPEN */

/* enable sockets support */
#define SW_SOCKETS 1

/* enable swoole stdext support */
/* #undef SW_STDEXT */

/* enable swoole thread support */
/* #undef SW_THREAD */

/* use boost asm context */
#define SW_USE_ASM_CONTEXT 1

/* do we enable c-ares support */
#define SW_USE_CARES 1

/* do we enable cURL native client */
#define SW_USE_CURL 1

/* do we enable firebird coro support */
/* #undef SW_USE_FIREBIRD */

/* have io_uring */
/* #undef SW_USE_IOURING */

/* use mysqlnd */
#define SW_USE_MYSQLND 1

/* do we enable swoole-odbc coro support */
/* #undef SW_USE_ODBC */

/* do we enable oracle coro support */
/* #undef SW_USE_ORACLE */

/* do we enable postgresql coro support */
#define SW_USE_PGSQL 1

/* do we enable sqlite coro support */
#define SW_USE_SQLITE 1

/* enable thread support */
/* #undef SW_USE_THREAD */

/* do we enable thread context */
/* #undef SW_USE_THREAD_CONTEXT */

/* enable io_uring socket support */
/* #undef SW_USE_URING_SOCKET */
